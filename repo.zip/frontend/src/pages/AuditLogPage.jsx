import React from 'react'

export default function AuditLogPage() {
  return (
    <section>
      <h2>Audit Log</h2>
      <p>Inspect append-only audit events for sensitive actions.</p>
    </section>
  )
}
