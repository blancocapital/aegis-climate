import React from 'react'

export default function ExceptionsPage() {
  return (
    <section>
      <h2>Exceptions Queue</h2>
      <p>Triaged items for Tier C data quality, low confidence geocodes, and unresolved warnings/errors.</p>
    </section>
  )
}
