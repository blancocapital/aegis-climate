import React from 'react'

export default function DriftPage() {
  return (
    <section>
      <h2>Portfolio Drift</h2>
      <p>Compare exposure versions to highlight new, removed, and modified locations plus aggregated changes.</p>
    </section>
  )
}
