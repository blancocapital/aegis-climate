import React from 'react'

export default function GovernancePage() {
  return (
    <section>
      <h2>Governance: Versions, Runs, Lineage</h2>
      <p>Trace outputs back to exposure versions, hazard datasets, rollup configs, and execution runs.</p>
    </section>
  )
}
