import React from 'react'

export default function AccumulationPage() {
  return (
    <section>
      <h2>Accumulation Dashboard</h2>
      <p>View rollups, hazard overlays, and drill down into contributing locations.</p>
    </section>
  )
}
