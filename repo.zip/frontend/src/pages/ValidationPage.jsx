import React from 'react'

export default function ValidationPage() {
  return (
    <section>
      <h2>Validation Summary</h2>
      <p>Review validation results, severity counts, and row-level errors.</p>
    </section>
  )
}
