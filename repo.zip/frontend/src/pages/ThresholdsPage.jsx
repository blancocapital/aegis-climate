import React from 'react'

export default function ThresholdsPage() {
  return (
    <section>
      <h2>Thresholds & Breaches</h2>
      <p>Define threshold rules, run breach evaluations, and manage breach statuses.</p>
    </section>
  )
}
