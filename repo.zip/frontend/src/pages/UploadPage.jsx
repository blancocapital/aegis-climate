import React from 'react'

export default function UploadPage() {
  return (
    <section>
      <h2>Upload & Mapping</h2>
      <p>Upload exposure files, attach mapping templates, and trigger validation.</p>
    </section>
  )
}
